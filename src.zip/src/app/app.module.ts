import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { ComponentsModule } from "./components/components.module";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { ToastrModule } from "ngx-toastr";
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AppComponent } from "./app.component";
import { AdminLayoutComponent } from "./layouts/admin-layout/admin-layout.component";
import { AuthLayoutComponent } from "./layouts/auth-layout/auth-layout.component";
import {MatStepperModule} from '@angular/material/stepper';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { ReactiveFormsModule } from '@angular/forms';
// import {NgxDatatableComponent} from './pages/tables/ngx-datatable/ngx-datatable.component'


import { AppRoutes } from "./app.routing";
import { MatStepperComponent } from './mat-stepper/mat-stepper.component';

@NgModule({
  declarations: [AppComponent, AdminLayoutComponent, AuthLayoutComponent, MatStepperComponent],
  imports: [
    BrowserAnimationsModule,
    NgxDatatableModule,
    RouterModule.forRoot(AppRoutes,{
      useHash: false
    }),
    NgbModule,
    ToastrModule.forRoot(), // ToastrModule added
    ComponentsModule,
    MatStepperModule,
    MatInputModule,
    MatButtonModule,
    MatAutocompleteModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
