import { Component, OnInit } from "@angular/core";
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
@Component({
  selector: "verification-form",
  templateUrl: "./verification.component.html",
  styleUrls: ["./verification.component.css"],
  inputs: ['rows', "id", "showDetails"],
})
export class VerificationFormComponent implements OnInit {    
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  isEditable = false;

  constructor(private _formBuilder: FormBuilder) {}

  ngOnInit() {
    console.log(this);
    this["account"] = this["rows"].find(({id}) => id == this["id"]);
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }  
  
}
