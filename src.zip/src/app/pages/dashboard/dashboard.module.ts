import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { ChartsModule } from "ng2-charts/ng2-charts";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { ComponentsModule } from "../../components/components.module";
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import {TablesModule} from './../tables/tables.module'
import { VerificationFormComponent } from './verification.component'
// import { NgxDatatableComponent } from './../tables/ngx-datatable/ngx-datatable.component'
import { DashTableComponent } from './dash.table.component'
import { DashboardRoutes } from "./dashboard.routing";
import { DashboardComponent } from "./dashboard.component";
import { CWSummaryComponent } from './cw.summary.component'
import { MatStepperModule } from '@angular/material/stepper'
import { MatFormFieldModule } from '@angular/material/form-field'
import {MatInputModule} from '@angular/material/input' 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// import { MatStepperComponent } from './../components/mat-stepper/mat-stepper.component'

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    NgxDatatableModule,
    RouterModule.forChild(DashboardRoutes),
    ComponentsModule,
    ChartsModule,
    TablesModule,
    MatStepperModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule
  ],
  declarations: [DashboardComponent, DashTableComponent, CWSummaryComponent, VerificationFormComponent],
  exports: [DashboardComponent]
})
export class DashboardModule {}
