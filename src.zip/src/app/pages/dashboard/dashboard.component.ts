import { Component, OnInit } from "@angular/core";
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";
// import * as Chartist from "chartist";
import {ActivatedRoute, Router} from '@angular/router';
import Chart from "chart.js";



@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"]
})



export class DashboardComponent implements OnInit {
  public gradientStroke;
  public chartColor = "#FFFFFF";
  public canvas: any;
  public ctx;
  public cardStatsMiniLineColor = "#fff";
  public cardStatsMiniDotColor = "#fff";
  public gradientFill;
  public gradientChartOptionsConfiguration: any;
  public gradientChartOptionsConfigurationWithNumbersAndGrid: any;
  public myChart: any;

  
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }
  public hexToRGB(hex, alpha) {
    var r = parseInt(hex.slice(1, 3), 16),
      g = parseInt(hex.slice(3, 5), 16),
      b = parseInt(hex.slice(5, 7), 16);

    if (alpha) {
      return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
    } else {
      return "rgb(" + r + ", " + g + ", " + b + ")";
    }
  }

  test: any =  `<button (click)="onSelect($event)">Click me</button>`;
  entries: number = 15;
  selected: any[] = [];
  temp = [];
  activeRow: any;
  rows = [
    {
      id: 1,
      accountid: "4534534",
      accountnumber: "112-123-100445",
      accountname: "Croline chao",
      clientcode: "15737701612379002",
      amount: "103",
      date: "07/28/2020",
      sdcstatus: "Regular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 2,
      accountid: "7675756",
      accountnumber: "112-123-79888",
      accountname: "Jimmy stood",
      clientcode: "445656546212342",
      amount: "7676",
      date: "07/28/2020",
      sdcstatus: "Regular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 3,
      accountid: "3423423",
      accountnumber: "112-123-12321",
      clientcode: "855756756767676",
      accountname: "Fidds catas",
      amount: "6565",
      date: "07/28/2020",
      sdcstatus: "Regular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },


    {
      id: 4,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 5,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 6,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 7,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "iRegular",
      overallstatus: "Success"
    },
    {
      id: 8,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "iRegular",
      overallstatus: "Success"
    },
    {
      id: 9,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "iRegular",
      overallstatus: "iRegular"
    },
    {
      id: 10,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 11,
      accountid: "4534534",
      accountnumber: "112-123-100445",
      accountname: "Croline chao",
      clientcode: "15737701612379002",
      amount: "103",
      date: "07/28/2020",
      sdcstatus: "Regular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 12,
      accountid: "7675756",
      accountnumber: "112-123-79888",
      accountname: "Jimmy stood",
      clientcode: "445656546212342",
      amount: "7676",
      date: "07/28/2020",
      sdcstatus: "Regular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 13,
      accountid: "3423423",
      accountnumber: "112-123-12321",
      clientcode: "855756756767676",
      accountname: "Fidds catas",
      amount: "6565",
      date: "07/28/2020",
      sdcstatus: "Regular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    
    
    {
      id: 14,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "iRegular",
      overallstatus: "Success"
    },
    {
      id: 15,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "iRegular"
    },
    {
      id: 16,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 17,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "iRegular",
      overallstatus: "Success"
    },
    {
      id: 18,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "iRegular"
    },
    {
      id: 19,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    },
    {
      id: 20,
      accountid: "2343243",
      accountnumber: "112-123-80797",
      clientcode: "34532646456454754",
      accountname: "Nicolas fredd",
      amount: "656",
      date: "07/28/2020",
      sdcstatus: "iRegular",
      opdstatus: "Success",
      creditstatus: "Success",
      overallstatus: "Success"
    }
  ];


  // rows = [
  //   { name: 'Austin', gender: 'Male', company: 'Swimlane' },
  //   { name: 'Dany', gender: 'Male', company: 'KFC' },
  //   { name: 'Molly', gender: 'Female', company: 'Burger King' },
  // ];
  // columns = [
  //   { prop: 'name' },
  //   { name: 'Gender' },
  //   { name: 'Company' }
  // ];


  constructor(private route:ActivatedRoute,private router:Router) {

    this.temp = this.rows.map((prop,key)=>{
      return {
        ...prop,
        id: key
      };

    });

  }

  entriesChange($event){
    this.entries = $event.target.value;
  }
  filterTable($event) {
    let val = $event.target.value;
    this.temp = this.rows.filter(function(d) {

      for(var key in d){
        if(d[key].toLowerCase().indexOf(val) !== -1){
          return true;
        }
      }
      return false;
    });
  }
  onSelect($event) {
   console.log('Select Event', $event);
 }
 onActivate(event) {
    this.activeRow = event.row;
  }
  likeFunction($event){
    $event.preventDefault();
    let details = "You've clicked LIKE button on \n{\n";
    for(var key in this.activeRow){
      details += key + ": " + this.activeRow[key] + "\n";
    }
    details += "}.";
    alert(details);
  }
  editFunction($event){
    $event.preventDefault();
    let details = "You've clicked EDIT button on \n{\n";
    for(var key in this.activeRow){
      details += key + ": " + this.activeRow[key] + "\n";
    }
    details += "}.";
    alert(details);
  }
  deleteFunction($event){
    $event.preventDefault();
    this.temp = this.rows.filter(entry => entry.id !== this.activeRow.id);
  }
  ViewDetails(id){
    this.router.navigate([`/verify/${id}`]);
  }

  ngOnInit() {
    // @ts-ignore
    this.showDetails = this.route.params.getValue("id")["id"];
    
  
  }
}
