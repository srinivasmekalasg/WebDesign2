import { Routes } from "@angular/router";

import { DashboardComponent } from "./dashboard.component";
import {VerificationFormComponent} from './verification.component'

export const DashboardRoutes: Routes = [
  {
    path: "",
    children: [
      {
        path: "dashboard",
        component: DashboardComponent
      },
      {
        path: "dashboard/verify/:id",
        component: DashboardComponent,
        // data: {showDetails: true}
      }
    ]
  }
];
