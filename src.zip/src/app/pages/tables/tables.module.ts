import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";

import { RegularTablesComponent } from "./regular-tables/regular-tables.component";
import { ExtendedTablesComponent } from "./extended-tables/extended-tables.component";
import { TablesRoutes } from "./tables.routing";
import { NgxDatatableComponent } from "./ngx-datatable/ngx-datatable.component";
import {MatStepperModule} from '@angular/material/stepper';
import {ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(TablesRoutes),
        NgxDatatableModule,
        MatStepperModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatButtonModule,
        MatInputModule
    ],
  declarations: [
    RegularTablesComponent,
    ExtendedTablesComponent,
    NgxDatatableComponent
  ]
})
export class TablesModule {}
