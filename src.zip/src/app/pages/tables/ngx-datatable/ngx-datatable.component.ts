import { Component, OnInit, ViewChild } from "@angular/core";

import {NgbModule} from "@ng-bootstrap/ng-bootstrap";
import { ToastrService } from "ngx-toastr";
import {ActivatedRoute, Router} from '@angular/router';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';




@Component({
  selector: "app-ngx-datatable",
  templateUrl: "./ngx-datatable.component.html",
  styleUrls: ["./ngx-datatable.component.css"]
})
export class NgxDatatableComponent implements OnInit {
  test: any =  `<button (click)="onSelect($event)">Click me</button>`;
  entries: number = 10;
  selected: any[] = [];
  temp = [];
  activeRow: any;
  rows: any = [
      {
          id: 0,
          accountid: "4534534",
          accountnumber: "112-123-100445",
          accountname: "Croline chao",
          clientcode: "15737701612379002",
          amount: "103",
          date: "07/28/2020",
          sdcstatus: "Regular",
          opdstatus: "Success",
          creditstatus: "Success",
          overallstatus: "Success"
      },
      {
          id: 1,
          accountid: "7675756",
          accountnumber: "112-123-79888",
          accountname: "Jimmy stood",
          clientcode: "445656546212342",
          amount: "7676",
          date: "07/28/2020",
          sdcstatus: "Regular",
          opdstatus: "Success",
          creditstatus: "Success",
          overallstatus: "Success"
      },
      {
          id: 2,
          accountid: "3423423",
          accountnumber: "112-123-12321",
          clientcode: "855756756767676",
          accountname: "Fidds catas",
          amount: "6565",
          date: "07/28/2020",
          sdcstatus: "Regular",
          opdstatus: "Success",
          creditstatus: "Success",
          overallstatus: "Success"
      },


      {
          id: 3,
          accountid: "2343243",
          accountnumber: "112-123-80797",
          clientcode: "34532646456454754",
          accountname: "Nicolas fredd",
          amount: "656",
          date: "07/28/2020",
          sdcstatus: "iRegular",
          opdstatus: "Success",
          creditstatus: "Success",
          overallstatus: "Success"
      }
  ];
  public id = 0;
  public subs$;
    isLinear = false;
    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;

    constructor(private toastr: ToastrService, private _route: ActivatedRoute, private _formBuilder: FormBuilder) {

    this.temp = this.rows.map((prop,key)=>{
      return {
        ...prop,
        id: key
      };

    });
      this.rows.filter((rows) => rows.id === this.id );

  }
  showNotification(from, align) {
    const color = Math.floor(Math.random() * 5 + 1);

    switch (color) {
      case 1:
   
        this.toastr.success(
          '<span class="now-ui-icons ui-1_check"></span> Success!  <b>Status</b> - has been update successfully.',
          "",
          {
            timeOut: 8000,
            closeButton: true,
            enableHtml: true,
            toastClass: "alert alert-success alert-with-icon",
            positionClass: "toast-" + from + "-" + align
          }
        );
        break;

      case 2:
        this.toastr.success(
          '<span class="now-ui-icons ui-1_check"></span> Success!  <b>Status</b> - has been update successfully.',
          "",
          {
            timeOut: 8000,
            closeButton: true,
            enableHtml: true,
            toastClass: "alert alert-success alert-with-icon",
            positionClass: "toast-" + from + "-" + align
          }
        );
        break;



      default:
        break;
    }
  }
  entriesChange($event){
    this.entries = $event.target.value;
  }
  filterTable($event) {
    let val = $event.target.value;
    this.temp = this.rows.filter(function(d) {

      for(var key in d){
        if(d[key].toLowerCase().indexOf(val) !== -1){
          return true;
        }
      }
      return false;
    });
  }
  onSelect($event) {
   console.log('Select Event', $event);
 }
 onActivate(event) {
    this.activeRow = event.row;
  }
  likeFunction($event){
    $event.preventDefault();
    let details = "You've clicked LIKE button on \n{\n";
    for(var key in this.activeRow){
      details += key + ": " + this.activeRow[key] + "\n";
    }
    details += "}.";
    alert(details);
  }
  editFunction($event){
    $event.preventDefault();
    let details = "You've clicked EDIT button on \n{\n";
    for(var key in this.activeRow){
      details += key + ": " + this.activeRow[key] + "\n";
    }
    details += "}.";
    alert(details);
  }
  deleteFunction($event){
    $event.preventDefault();
    this.temp = this.rows.filter(entry => entry.id !== this.activeRow.id);
  }
  ngOnInit() {

    this.subs$ = this._route
        .queryParams
        .subscribe((params) => {
          this.id = params["id"];
            this.temp = this.rows.filter((row) => row.id === Number(this.id) );
          console.log(this.id);
        })
      this.firstFormGroup = this._formBuilder.group({
          firstCtrl: ['', Validators.required]
      });
      this.secondFormGroup = this._formBuilder.group({
          secondCtrl: ['', Validators.required]
      });
  }
  ngOnDestroy() {
    if (this.subs$) {
      this.subs$.unsubscribe();
    }
  }
}
