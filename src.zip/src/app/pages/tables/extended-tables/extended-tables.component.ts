import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-extended-tables",
  templateUrl: "./extended-tables.component.html",
  styleUrls: ["./extended-tables.component.css"]
})
export class ExtendedTablesComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
