import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-vector-map",
  templateUrl: "./vector-map.component.html",
  styleUrls: ["./vector-map.component.css"]
})
export class VectorMapComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
