import { Component, OnInit, Input, TemplateRef } from "@angular/core";
import { NgbCalendar, NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import {CountriesService} from "../../../countries.service";


@Component({
  selector: "app-extended-forms",
  templateUrl: "./extended-forms.component.html",
  styleUrls: ["./extended-forms.component.css"]
})
export class ExtendedFormsComponent implements OnInit {


  private state: boolean = true;
  private state1: boolean = true;
  private state2: boolean = true;

  private dropdownList = [];
  private selectedItems = [];
  private dropdownSettings = {};

  private dropdownList1 = [];
  private selectedItems1 = [];
  private dropdownSettings1 = {};

  private dropdownList2 = [];
  private selectedItems2 = [];
  private dropdownSettings2 = {};

  private dropdownList3 = [];
  private selectedItems3= [];
  private dropdownSettings3 = {};

  private dropdownList4 = [];
  private selectedItems4= [];
  private dropdownSettings4 = {};

  stateInfo: any[] = [];
  countryInfo = [];
  cityInfo: any[] = [];
  allCountries:any = [];


  constructor(private country: CountriesService ) {}


  ngOnInit() {


    // City
    this.dropdownList = [
      { id: 1, itemName: "USA" },
      { id: 2, itemName: "UK" },
      { id: 3, itemName: "India" },
      { id: 4, itemName: "Canada" },
      { id: 5, itemName: "Germany" },
      { id: 6, itemName: "China" }
    ];
    this.selectedItems = [ ];

    this.dropdownSettings = {
      singleSelection: true,
      text: "Select City",
      selectAllText:'Select All',
      unSelectAllText:'UnSelect All',
      enableSearchFilter: false,
      classes:"myclass custom-class"
    };





    // this.dropdownList2 = [
    //   { id: 1, itemName: "Roman" },
    //   { id: 2, itemName: "Paris" },
    //   { id: 3, itemName: "Bucharest" },
    //   { id: 4, itemName: "Rome" },
    //   { id: 5, itemName: "New York" },
    //   { id: 6, itemName: "Miami" },
    //   { id: 7, itemName: "Piatra Neamt" },
    //   { id: 8, itemName: "Paris" },
    //   { id: 9, itemName: "Bucharest" },
    //   { id: 10, itemName: "Rome" },
    //   { id: 11, itemName: "New York" },
    //   { id: 12, itemName: "Miami" },
    //   { id: 13, itemName: "Piatra Neamt" }
    // ];
    this.selectedItems2= [];
    this.dropdownSettings2 = {
      singleSelection: true,
      text: "Select State",
      selectAllText:'Select All',
      unSelectAllText:'UnSelect All',
      enableSearchFilter: false,
      classes:"myclass custom-class"
    };


    // Currency
    this.dropdownList3 = [

      { id: 1, itemName: "USD" },
      { id: 2, itemName: "CAD" },
      { id: 3, itemName: "EURO" },
      { id: 4, itemName: "POUND" },

    ];
    this.selectedItems3= [];
    this.dropdownSettings3 = {
      singleSelection: true,
      text:"Select Currency",
      selectAllText:'Select All',
      unSelectAllText:'UnSelect All',
      enableSearchFilter: false,
      classes:"myclass custom-class"
    };

    this.dropdownList4 = [
      { id: 1, itemName: "Roman" },
      { id: 2, itemName: "Paris" },
      { id: 3, itemName: "Bucharest" },
      { id: 4, itemName: "Rome" },
      { id: 5, itemName: "New York" },
      { id: 6, itemName: "Miami" },
      { id: 7, itemName: "Piatra Neamt" },
      { id: 8, itemName: "Paris" },
      { id: 9, itemName: "Bucharest" },
      { id: 10, itemName: "Rome" },
      { id: 11, itemName: "New York" },
      { id: 12, itemName: "Miami" },
      { id: 13, itemName: "Piatra Neamt" }
    ];
    this.selectedItems4 = [];
    this.dropdownSettings4 = {
      singleSelection: true,
      text: "Select City",
      selectAllText:'Select All',
      unSelectAllText:'UnSelect All',
      enableSearchFilter: false,
      classes:"myclass custom-class"
    };


// this.dropdownList1 = [
    //   { id: 1, itemName: "USA" },
    //   { id: 2, itemName: "UK" },
    //   { id: 3, itemName: "India" },
    //   { id: 4, itemName: "Canada" },
    //   { id: 5, itemName: "Germany" },
    //   { id: 6, itemName: "China" }
    // ];
    this.dropdownList1 = this.getCountries();
    this.getCountries();
    this.selectedItems1 = [];
    this.dropdownSettings1 = {
      singleSelection: true,
      text: "Select Country",
      selectAllText:'Select All',
      unSelectAllText:'UnSelect All',
      enableSearchFilter: false,
      classes:"myclass custom-class"
    };
  }

  getCountries(){
    this.country.allCountries().
    subscribe(
        data2 => {
          this.allCountries = data2.Countries;
          let i = 0;
          data2.Countries.forEach((element,index) => {

            this.countryInfo.push({
              'id':index+1,
              'itemName':element.CountryName
            });
          });

          //console.log('Data:', this.countryInfo);

        },
        err => console.log(err),
        () => console.log('complete')
    )
    return this.countryInfo;
  }
  onChangeCountry(countryValue) {
    this.stateInfo=this.countryInfo[countryValue].States;
    this.cityInfo=this.stateInfo[0].Cities;
    console.log(this.cityInfo);
  }

  onChangeState(stateValue) {
    this.cityInfo=this.stateInfo[stateValue].Cities;
    //console.log(this.cityInfo);
  }
  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }

  onItemSelect1(item: any) {
    // console.log(item);
    // console.log(this.selectedItems1);
    // console.log(item);
    // console.log(this.selectedItems1);
    // this.allCountries.forEach(x=>{
    //   if(item.itemName == x.CountryName)
    //     this.dropdownList2.push(x);
    // });
    // console.log(this.dropdownList2);
    console.log(item);
    console.log(this.selectedItems1);
    this.dropdownList2 = this.allCountries.map(x=>{
      if(item.itemName == x.CountryName){
        return x;
      }
    });
    console.log(this.dropdownList2);//implement in your state dropdown
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }
}
